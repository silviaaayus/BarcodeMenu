<?php

include 'kon.php';
header('Content-Type: application/json');

$array = array();
$id_kategori= $_GET['id_kategori'];

$query = mysql_query(
		"SELECT * FROM tb_produk WHERE id_kategori='$id_kategori' "
);

$i = 0;
while ($hasil = mysql_fetch_assoc($query)) {
	array_push($array, $hasil);
	$i++;
}

$res = array("status" => "sukses", "res" => $array);

echo json_encode($res);

?>
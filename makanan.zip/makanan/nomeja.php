<?php

header('Content-Type: application/json');

$token = $_GET['token'];
$output = array(
	"status" => 1, 
	"nomeja" => "07", 
	"token" => $token
);

echo json_encode($output);

?>
<?php

include 'kon.php';
header('Content-Type: application/json');

$token = $_GET['token'];

$array = array();


$query = mysql_query(
		"SELECT a.*,  b.*  FROM tb_pesanan_detail a
		LEFT JOIN tb_produk b ON a.id_produk = b.id_produk
		WHERE a.token='$token' 
		"
);

$i = 0;
while ($hasil = mysql_fetch_assoc($query)) {
	array_push($array, $hasil);
	$i++;
}

$res = array("status" => "sukses", "res" => $array);

echo json_encode($res);

?>
<?php

include 'kon.php';
header('Content-Type: application/json');

$array = array();
$password = $_POST['password'];

$query = mysql_query(
		"SELECT * FROM tb_makanan_minuman WHERE type=1"
);

$i = 0;
while ($hasil = mysql_fetch_assoc($query)) {
	array_push($array, $hasil);
	$i++;
}

$res = array("status" => "sukses", "res" => $array);

echo json_encode($res);

?>
-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jul 03, 2021 at 07:07 AM
-- Server version: 5.6.20
-- PHP Version: 5.5.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `db_makanan`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_kategori`
--

CREATE TABLE IF NOT EXISTS `tb_kategori` (
`id_kategori` int(11) NOT NULL,
  `jenis` int(11) NOT NULL,
  `kategori` varchar(255) NOT NULL,
  `gambar_kategori` varchar(255) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `tb_kategori`
--

INSERT INTO `tb_kategori` (`id_kategori`, `jenis`, `kategori`, `gambar_kategori`) VALUES
(1, 1, 'Cakue & Snack', 'cakue.jpg'),
(2, 1, 'Indonesian Food', 'nasgor.png'),
(3, 1, 'Japanese Food', 'japan.jpeg'),
(4, 1, 'Pasta', 'pasta.jpg'),
(5, 2, 'Jus', 'alpukat.jpg'),
(6, 2, 'Tea', 'icetea.png'),
(7, 2, 'Coffe and Hot Drinks', 'coffe.png'),
(8, 2, 'Could Drinks', 'could.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tb_pesanan`
--

CREATE TABLE IF NOT EXISTS `tb_pesanan` (
`id_pesanan` int(11) NOT NULL,
  `token` text NOT NULL,
  `tanggal` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `total_pembayaran` int(11) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=25 ;

--
-- Dumping data for table `tb_pesanan`
--

INSERT INTO `tb_pesanan` (`id_pesanan`, `token`, `tanggal`, `total_pembayaran`, `status`) VALUES
(17, 'egertujhgdfsawer45tyhnbvfdwertyhgbvdswertyhgfderthgbvderth', '2021-01-12 03:34:16', 176000, 0),
(18, 'Tew1123asd13g1d1e', '2021-01-12 03:41:28', 99000, 0),
(19, 'klkgyfdrdgcghkyutrdgcvhjytresdfghyuredfgh', '2021-01-12 08:57:00', 88000, 0),
(20, 'jhgfdsfgvhbjkjhgfcdxcv bnjhghfcv bnjhgvb njhgvb njhgvb n', '2021-01-14 08:21:16', 44000, 0),
(21, '9-', '2021-01-18 04:08:31', 44000, 0),
(22, 'gfdaasdfghjklkmjhgfdsdfgbh', '2021-04-17 02:56:19', 16500, 0),
(23, 'jhgfdsfghjklhcx', '2021-04-22 03:10:20', 5500, 0),
(24, 'kjhgfdsadfghjkljhgfdsdxgvbnm,nbvcxdsfertyhjnb bcghbn bvcfgrtyhbvcfgh', '2021-06-28 03:53:50', 22000, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tb_pesanan_detail`
--

CREATE TABLE IF NOT EXISTS `tb_pesanan_detail` (
`id_detail` int(11) NOT NULL,
  `token` text NOT NULL,
  `tanggal` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `id_produk` int(11) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `harga` int(11) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=45 ;

--
-- Dumping data for table `tb_pesanan_detail`
--

INSERT INTO `tb_pesanan_detail` (`id_detail`, `token`, `tanggal`, `id_produk`, `jumlah`, `harga`) VALUES
(29, 'egertujhgdfsawer45tyhnbvfdwertyhgbvdswertyhgfderthgbvderth', '2021-01-12 03:28:02', 2, 3, 15000),
(30, 'egertujhgdfsawer45tyhnbvfdwertyhgbvdswertyhgfderthgbvderth', '2021-01-12 03:28:02', 1, 4, 25000),
(32, 'egertujhgdfsawer45tyhnbvfdwertyhgbvdswertyhgfderthgbvderth', '2021-01-12 03:34:16', 3, 3, 5000),
(33, 'Tew1123asd13g1d1e', '2021-01-12 03:41:28', 2, 1, 15000),
(34, 'Tew1123asd13g1d1e', '2021-01-12 03:41:28', 1, 3, 25000),
(35, 'klkgyfdrdgcghkyutrdgcvhjytresdfghyuredfgh', '2021-01-12 08:57:01', 2, 2, 15000),
(36, 'klkgyfdrdgcghkyutrdgcvhjytresdfghyuredfgh', '2021-01-12 08:57:01', 1, 2, 25000),
(37, 'jhgfdsfgvhbjkjhgfcdxcv bnjhghfcv bnjhgvb njhgvb njhgvb n', '2021-01-14 08:21:16', 2, 1, 15000),
(38, 'jhgfdsfgvhbjkjhgfcdxcv bnjhghfcv bnjhgvb njhgvb njhgvb n', '2021-01-14 08:21:16', 1, 1, 25000),
(39, '9-', '2021-01-18 04:08:31', 2, 1, 15000),
(40, '9-', '2021-01-18 04:08:31', 1, 1, 25000),
(41, 'gfdaasdfghjklkmjhgfdsdfgbh', '2021-04-17 02:56:19', 2, 1, 15000),
(42, 'jhgfdsfghjklhcx', '2021-04-22 03:10:20', 3, 1, 5000),
(43, 'kjhgfdsadfghjkljhgfdsdxgvbnm,nbvcxdsfertyhjnb bcghbn bvcfgrtyhbvcfgh', '2021-06-28 03:53:50', 2, 1, 15000),
(44, 'kjhgfdsadfghjkljhgfdsdxgvbnm,nbvcxdsfertyhjnb bcghbn bvcfgrtyhbvcfgh', '2021-06-28 03:53:50', 3, 1, 5000);

-- --------------------------------------------------------

--
-- Table structure for table `tb_produk`
--

CREATE TABLE IF NOT EXISTS `tb_produk` (
`id_produk` int(11) NOT NULL,
  `id_kategori` int(11) NOT NULL,
  `nama_produk` varchar(255) NOT NULL,
  `harga_produk` int(11) NOT NULL,
  `gambar_produk` varchar(255) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `tb_produk`
--

INSERT INTO `tb_produk` (`id_produk`, `id_kategori`, `nama_produk`, `harga_produk`, `gambar_produk`) VALUES
(1, 2, 'Nasi Goreng', 25000, 'nasgor.png'),
(2, 2, 'Kwetiau', 15000, 'nasgor.png'),
(3, 5, 'Teh es', 5000, '');

-- --------------------------------------------------------

--
-- Table structure for table `tmp_pesanan`
--

CREATE TABLE IF NOT EXISTS `tmp_pesanan` (
`id_tmp` int(11) NOT NULL,
  `token` text NOT NULL,
  `id_produk` int(11) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `harga` int(11) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `tmp_pesanan`
--

INSERT INTO `tmp_pesanan` (`id_tmp`, `token`, `id_produk`, `jumlah`, `harga`) VALUES
(3, 'jhytrdfxvbnjkuytrdfxcvbnmkjliytfgcvbnkjluytfgcvbnjkhghc', 1, 1, 25000),
(4, 'jhytrdfxvbnjkuytrdfxcvbnmkjliytfgcvbnkjluytfgcvbnjkhghc', 2, 1, 15000);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_kategori`
--
ALTER TABLE `tb_kategori`
 ADD PRIMARY KEY (`id_kategori`);

--
-- Indexes for table `tb_pesanan`
--
ALTER TABLE `tb_pesanan`
 ADD PRIMARY KEY (`id_pesanan`);

--
-- Indexes for table `tb_pesanan_detail`
--
ALTER TABLE `tb_pesanan_detail`
 ADD PRIMARY KEY (`id_detail`);

--
-- Indexes for table `tb_produk`
--
ALTER TABLE `tb_produk`
 ADD PRIMARY KEY (`id_produk`);

--
-- Indexes for table `tmp_pesanan`
--
ALTER TABLE `tmp_pesanan`
 ADD PRIMARY KEY (`id_tmp`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_kategori`
--
ALTER TABLE `tb_kategori`
MODIFY `id_kategori` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `tb_pesanan`
--
ALTER TABLE `tb_pesanan`
MODIFY `id_pesanan` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=25;
--
-- AUTO_INCREMENT for table `tb_pesanan_detail`
--
ALTER TABLE `tb_pesanan_detail`
MODIFY `id_detail` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=45;
--
-- AUTO_INCREMENT for table `tb_produk`
--
ALTER TABLE `tb_produk`
MODIFY `id_produk` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `tmp_pesanan`
--
ALTER TABLE `tmp_pesanan`
MODIFY `id_tmp` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

<?php

include 'kon.php';
header('Content-Type: application/json');

$id_produk = $_POST['id_produk'];

$cek = mysql_query(
		"SELECT * FROM `tmp_pesanan` WHERE `id_produk`='$id_produk' "
);
if (mysql_num_rows($cek)>0){
	$f = mysql_fetch_array($cek);
	$jml = $f['jumlah'] + 1;

	$sql =mysql_query("UPDATE `db_makanan`.`tmp_pesanan` SET `jumlah` = '$jml' WHERE `tmp_pesanan`.`id_produk` = '$id_produk'");
	if ($sql) {
		echo "sukses";
	}else{
		echo "gagal";
	}
}
else{	
$sql = mysql_query("INSERT INTO `tmp_pesanan` (`id_tmp`, `id_produk`, `jumlah`, `harga`) VALUES (NULL, '$id_produk', '1', '')");
if ($sql) {
		echo "sukses";
	}else{
		echo "gagal";
	}
}
?>
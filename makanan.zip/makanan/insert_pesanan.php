<?php

include 'kon.php';
header('Content-Type: application/json');

$token = $_POST['token'];
$total_pembayaran = $_POST['total_pembayaran'];


$cek = mysql_query(
	"SELECT * FROM tb_pesanan WHERE token = '$token'"
);

if (mysql_num_rows($cek)==0){
	$sql =mysql_query(
		"
		INSERT INTO tb_pesanan (token, total_pembayaran, status)
		VALUES( 
		'$token', '$total_pembayaran', '0')
		");

	$sql2 =mysql_query(
		"
		INSERT INTO tb_pesanan_detail (`token`, `id_produk`, `jumlah`, `harga`)
		SELECT `token`, `id_produk`, `jumlah`, `harga` FROM tmp_pesanan WHERE token = '$token'
		"
	);

	$sql3 =mysql_query(
		"
		DELETE FROM tmp_pesanan WHERE token = '$token'
		"
	);

	if ($sql && $sql2 && $sql3) {
		$res = array("status" => 1, "message" => "sukses memesan");
	}
	else{
		$res = array("status" => 0, "message" => "gagal memesan");
	}
	echo json_encode($res);
	// echo mysql_error($con);
}
else{
	$f = mysql_fetch_array($cek);
	$jml = $f['total_pembayaran'] + $total_pembayaran;	
	$sql =mysql_query(
		"
		UPDATE tb_pesanan SET 
		total_pembayaran = '$jml'
		WHERE token = '$token'
		");

	$cek = mysql_query(
		"SELECT * FROM `tmp_pesanan` WHERE token = '$token'"
	);

	while ($f = mysql_fetch_array($cek)) {
		$id = $f['id_produk'];
		$jum = $f['jumlah'];
		$har = $f['harga'];
		$cek2 = mysql_query(
			"SELECT * FROM `tb_pesanan_detail` WHERE token = '$token' AND id_produk = '$id'" 
		);
		if (mysql_num_rows($cek2)>0) {
			$h = mysql_fetch_array($cek2);
			$jml_detail = $jum + $h['jumlah'];
			$up = mysql_query("UPDATE tb_pesanan_detail SET jumlah = '$jml_detail' WHERE token = '$token' AND id_produk = '$id'");
			// echo "atas";
		}
		else{
			// echo "bawah";
			$ins = mysql_query("
				INSERT INTO tb_pesanan_detail (`token`, `id_produk`, `jumlah`, `harga`)
				VALUES
				('$token', '$id', '$jum', '$har')
				");
		}
	}



	// $sql2 =mysql_query(
	// 	"
	// 	INSERT INTO tb_pesanan_detail (`token`, `id_produk`, `jumlah`, `harga`)
	// 	SELECT `token`, `id_produk`, `jumlah`, `harga` FROM tmp_pesanan WHERE token = '$token'
	// 	"
	// );

	$sql3 =mysql_query(
		"
		DELETE FROM tmp_pesanan WHERE token = '$token'
		"
	);

	if ($sql) {
		$res = array("status" => 1, "message" => "sukses memesan");
	}
	else{
		$res = array("status" => 0, "message" => "gagal memesan besar dari 0");
	}
	echo json_encode($res);

	// echo mysql_error($con);

	// echo "asu";
}
?>
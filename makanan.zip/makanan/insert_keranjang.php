<?php

include 'kon.php';
header('Content-Type: application/json');

$token = $_POST['token'];
$id_produk = $_POST['id_produk'];
$jumlah = $_POST['jumlah'];
$harga = $_POST['harga'];

$cek = mysql_query(
	"SELECT * FROM `tmp_pesanan` WHERE token = '$token' AND `id_produk`='$id_produk'"
);

if (mysql_num_rows($cek)>0){
	if ($jumlah == 0) {
		$sql =mysql_query("DELETE FROM `db_makanan`.`tmp_pesanan`
			WHERE 
			`tmp_pesanan`.`token` = '$token' AND
			`tmp_pesanan`.`id_produk` = '$id_produk'
			");
		$res = array("status" => 1, "message" => "sukses delete");

		echo json_encode($res);
	}
	else{
		$sql =mysql_query("UPDATE `db_makanan`.`tmp_pesanan` SET `jumlah` = '$jumlah' 
			WHERE 
			`tmp_pesanan`.`token` = '$token' AND
			`tmp_pesanan`.`id_produk` = '$id_produk'
			");
		if ($sql) {
			$res = array("status" => 1, "message" => "sukses");

			echo json_encode($res);
		}else{
			$res = array("status" => 0, "message" => "gagal input ke keranjang");

			echo json_encode($res);
		}
	}
}
else{	
	if ($jumlah == 0) {
		
	}
	else{
		$sql = mysql_query(
			"INSERT INTO `tmp_pesanan` 
			(`token`, `id_produk`, `jumlah`, `harga`) 
			VALUES 
			('$token', '$id_produk', '$jumlah', '$harga')
			");
		if ($sql) {
			$res = array("status" => 1, "message" => "sukses");

			echo json_encode($res);
		}else{
			$res = array("status" => 0, "message" => "gagal");

			echo json_encode($res);
		}
	}
}
?>
<?php 

$con = mysql_connect('localhost', 'root', '');
mysql_select_db("db_makanan");
// if ($con) {
// 	echo 'sukses';
// }
// else {
// 	echo "gagal";
// }

?>